#pragma once
#include "Geometry.hpp"
#include <cstdint>
#include <string_view>
struct EffectContext{float time=0,amount=1,bass=0,mid=0,treble=0,beat=0;uint32_t seed=1;};
constexpr int effectCount(){return 64;}
std::string_view effectName(int id);
bool applyEffect(Mesh&,int id,const EffectContext&,const Mesh* secondary=nullptr);
