#pragma once
#include "Effects.hpp"
#include <array>
#include <cstdint>
#include <string_view>

struct EffectStage {
    int effect = 0;
    float amount = 1.0f;
    float timeScale = 1.0f;
    float timeOffset = 0.0f;
    uint32_t seedOffset = 0;
    bool useSecondary = false;
};
struct EffectRecipe {
    std::string_view name;
    std::array<EffectStage,6> stages{};
    int stageCount = 0;
};
constexpr int recipeCount(){ return 24; }
std::string_view recipeName(int id);
EffectRecipe recipe(int id);
EffectRecipe mutateRecipe(uint32_t seed, int depth=4);
bool applyRecipe(Mesh&, const EffectRecipe&, const EffectContext&, const Mesh* secondary=nullptr);
