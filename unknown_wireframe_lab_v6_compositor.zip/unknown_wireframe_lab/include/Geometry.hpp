#pragma once
#include <cstddef>
#include <string_view>
#include <vector>
#include "Math.hpp"
struct Mesh{std::vector<V3> v; std::vector<unsigned> e;};
struct MeshStats{size_t vertices=0,edges=0,duplicateEdges=0,zeroLengthEdges=0;V3 min{},max{};float radius=0;};
Mesh makeObject(int id,float t,int quality=40);
std::string_view objectName(int id);
bool validateMesh(const Mesh&, const char** why=nullptr);
MeshStats meshStats(const Mesh&);
constexpr int objectCount(){return 49;}
