#pragma once
#include "Geometry.hpp"
class Renderer{
 unsigned prog=0,vao=0,vbo=0,ebo=0; int mvpLoc=-1,timeLoc=-1;
 void reset() noexcept;
public:
 Renderer()=default; ~Renderer(); Renderer(const Renderer&)=delete; Renderer&operator=(const Renderer&)=delete;
 bool init(); void draw(const Mesh&,const M4&,float);
};
