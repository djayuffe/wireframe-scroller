#pragma once
#include <cmath>
struct V3{float x=0,y=0,z=0; V3 operator+(V3 b)const{return{x+b.x,y+b.y,z+b.z};} V3 operator-(V3 b)const{return{x-b.x,y-b.y,z-b.z};} V3 operator*(float s)const{return{x*s,y*s,z*s};} V3 operator/(float s)const{return{x/s,y/s,z/s};}};
inline float dot(V3 a,V3 b){return a.x*b.x+a.y*b.y+a.z*b.z;} inline V3 cross(V3 a,V3 b){return{a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};} inline float len(V3 a){return std::sqrt(dot(a,a));} inline V3 norm(V3 a){float l=len(a);return l>1e-8f?a/l:V3{};}
struct M4{float m[16]{};};
inline M4 mul(M4 a,M4 b){M4 r{};for(int c=0;c<4;c++)for(int rr=0;rr<4;rr++)for(int k=0;k<4;k++)r.m[c*4+rr]+=a.m[k*4+rr]*b.m[c*4+k];return r;}
inline M4 perspective(float f,float asp,float n,float z){M4 r{};float q=1.f/std::tan(f*.5f);r.m[0]=q/asp;r.m[5]=q;r.m[10]=(z+n)/(n-z);r.m[11]=-1;r.m[14]=2*z*n/(n-z);return r;}
inline M4 lookAt(V3 e,V3 c,V3 up){V3 f=norm(c-e),s=norm(cross(f,up)),u=cross(s,f);M4 r{};r.m[0]=s.x;r.m[4]=s.y;r.m[8]=s.z;r.m[1]=u.x;r.m[5]=u.y;r.m[9]=u.z;r.m[2]=-f.x;r.m[6]=-f.y;r.m[10]=-f.z;r.m[15]=1;r.m[12]=-dot(s,e);r.m[13]=-dot(u,e);r.m[14]=dot(f,e);return r;}
