#version 330 core
layout(location=0) in vec3 P;
uniform mat4 MVP; uniform float T; out float fade;
void main(){vec4 q=MVP*vec4(P,1.0);gl_Position=q;float z=abs(q.z/max(abs(q.w),1e-5));fade=clamp(1.08-z*.13,0.20,1.0);}
