#version 330 core
in float fade; uniform float T; out vec4 C;
void main(){float p=.90+.10*sin(T*1.7);vec3 c=vec3(.48,.80,1.0)*fade*p;C=vec4(c,.35+.65*fade);}
