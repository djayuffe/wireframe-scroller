#include "Geometry.hpp"
#include <cstdio>
int main(){for(int id=0;id<objectCount();++id){Mesh m=makeObject(id,0.731f,48);auto s=meshStats(m);std::printf("%02d %-28.*s v=%5zu e=%5zu dup=%3zu zero=%zu radius=%6.3f bounds=[%6.2f,%6.2f] [%6.2f,%6.2f] [%6.2f,%6.2f]\n",id,(int)objectName(id).size(),objectName(id).data(),s.vertices,s.edges,s.duplicateEdges,s.zeroLengthEdges,s.radius,s.min.x,s.max.x,s.min.y,s.max.y,s.min.z,s.max.z);}return 0;}
