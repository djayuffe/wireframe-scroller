#include "Geometry.hpp"
#include <cmath>
#include <cstdio>
#include <cstring>
#include <limits>
static bool same(const Mesh&a,const Mesh&b){return a.v.size()==b.v.size()&&a.e==b.e&&(a.v.empty()||std::memcmp(a.v.data(),b.v.data(),a.v.size()*sizeof(V3))==0);}
int main(){size_t total=0;for(int id=-objectCount();id<2*objectCount();id++){for(int k=0;k<32;k++){float t=(k-20)*.371f;for(int q: {1,12,31,48,96,200}){Mesh m=makeObject(id,t,q);const char*w=nullptr;if(!validateMesh(m,&w)){std::fprintf(stderr,"FAIL id=%d t=%g q=%d: %s\n",id,t,q,w?w:"?");return 1;}auto st=meshStats(m);if(st.zeroLengthEdges||st.radius>100.f){std::fprintf(stderr,"BAD STATS id=%d zero=%zu radius=%g\n",id,st.zeroLengthEdges,st.radius);return 2;}++total;}}}
for(int id=0;id<objectCount();++id){Mesh a=makeObject(id,1.2345f,48),b=makeObject(id,1.2345f,48);if(!same(a,b)){std::fprintf(stderr,"NONDETERMINISTIC id=%d\n",id);return 3;}Mesh lo=makeObject(id,0,1),lo2=makeObject(id,0,12),hi=makeObject(id,0,200),hi2=makeObject(id,0,96);if(!same(lo,lo2)||!same(hi,hi2)){std::fprintf(stderr,"QUALITY CLAMP FAIL id=%d\n",id);return 4;}}
if(objectName(-1)!=objectName(objectCount()-1)||objectName(objectCount())!=objectName(0)){std::fprintf(stderr,"ID WRAP FAIL\n");return 5;}
Mesh bad;const char*w=nullptr;if(validateMesh(bad,&w)){return 6;}bad.v={{0,0,0},{0,0,0}};bad.e={0,1};if(validateMesh(bad,&w)){return 7;}bad.v[1]={std::numeric_limits<float>::quiet_NaN(),0,0};if(validateMesh(bad,&w)){return 8;}
std::printf("PASS: %zu generated meshes + determinism/clamp/negative tests\n",total);return 0;}
