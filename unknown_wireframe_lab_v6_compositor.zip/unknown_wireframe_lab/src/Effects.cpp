#include "Effects.hpp"
#include <algorithm>
#include <cmath>
#include <functional>
#include <limits>
static constexpr float PI=3.14159265358979323846f;
static int wrap(int x,int n){x%=n;return x<0?x+n:x;}
static float clampf(float x,float a,float b){return std::max(a,std::min(b,x));}
static uint32_t hash32(uint32_t x){x^=x>>16;x*=0x7feb352dU;x^=x>>15;x*=0x846ca68bU;x^=x>>16;return x;}
static float rnd(uint32_t x){return float(hash32(x)&0xffffff)/float(0xffffff)*2.f-1.f;}
static V3 center(const Mesh&m){V3 c{};for(auto p:m.v)c=c+p;return m.v.empty()?c:c/float(m.v.size());}
static void mapv(Mesh&m,const std::function<V3(V3,size_t)>&f){for(size_t i=0;i<m.v.size();++i)m.v[i]=f(m.v[i],i);}
static void cull(Mesh&m,const std::function<bool(V3,V3,size_t)>&f){std::vector<unsigned> e;e.reserve(m.e.size());for(size_t i=0;i+1<m.e.size();i+=2){unsigned a=m.e[i],b=m.e[i+1];if(a<m.v.size()&&b<m.v.size()&&f(m.v[a],m.v[b],i/2)){e.push_back(a);e.push_back(b);}}m.e.swap(e);}
static void copy(Mesh&d,const Mesh&s,V3 o,float sc,float a){unsigned base=(unsigned)d.v.size();float C=cosf(a),S=sinf(a);for(auto p:s.v)d.v.push_back({(p.x*C-p.z*S)*sc+o.x,p.y*sc+o.y,(p.x*S+p.z*C)*sc+o.z});for(auto i:s.e)d.e.push_back(base+i);}
static void subdiv(Mesh&m,int n,float j,uint32_t seed){n=std::clamp(n,1,8);Mesh o;for(size_t z=0;z+1<m.e.size();z+=2){V3 a=m.v[m.e[z]],b=m.v[m.e[z+1]],d=b-a,side=norm(cross(d,{.31f,.73f,.19f}));unsigned prev=(unsigned)o.v.size();o.v.push_back(a);for(int k=1;k<=n;k++){float u=float(k)/n;V3 p=a+d*u;if(k<n)p=p+side*(j*rnd(seed+(uint32_t)(z*17+k)));unsigned cur=(unsigned)o.v.size();o.v.push_back(p);o.e.insert(o.e.end(),{prev,cur});prev=cur;}}m=std::move(o);}

static void sanitize(Mesh&m){std::vector<unsigned> out;out.reserve(m.e.size());for(size_t i=0;i+1<m.e.size();i+=2){unsigned a=m.e[i],b=m.e[i+1];if(a>=m.v.size()||b>=m.v.size()||a==b)continue;if(len(m.v[a]-m.v[b])<=1e-5f)continue;out.push_back(a);out.push_back(b);}m.e.swap(out);}
std::string_view effectName(int id){static const char*n[]={"None","Twist","Bend","Taper","Pulse","Ripple","Noise Warp","Quantize","Mirror Fold","Sphericalize","Cubify","Inversion","Vortex","Shear Wave","Radial Wave","Axis Permute","Mobius Phase","Kaleidoscope","Polar Quantize","Breathing Shell","Pinch","Explode","Implode","Shatter","Edge Pulse","Scan Slice","Venetian Slice","Checker Cull","Radial Cull","Depth Cull","Phase Cull","Echo Copies","Orbit Copies","Recursive Copies","Trail Copies","Time Shear","Dual Bridge","Nearest Bridge","Centroid Spokes","Constellation","Edge Subdivide","Edge Fracture","Edge Braid","Edge Lightning","Gravity Lens","Black Hole Ring","Wormhole Pair","Event Horizon","Caustic Fold","Projective Singularity","Hyper Perspective","Fisheye 3D","Stereo Split","Chromatic Geometry","Audio Radial","Audio Twist","Audio Bands","Beat Shatter","Bass Breath","Treble Noise","Spectral Rings","Flow Advection","Curl Warp","Domain Warp"};return n[wrap(id,effectCount())];}
bool applyEffect(Mesh&m,int iid,const EffectContext&c,const Mesh*s){if(m.v.empty())return false;Mesh original=m;int id=wrap(iid,effectCount());float A=clampf(c.amount,-4,4),t=c.time;V3 C=center(m);auto q=[&](V3 p){return p-C;};
 switch(id){
 case 0:break;case 1:mapv(m,[&](V3 p,size_t){V3 x=q(p);float a=A*.7f*x.y+.2f*sinf(t),co=cosf(a),si=sinf(a);return C+V3{x.x*co-x.z*si,x.y,x.x*si+x.z*co};});break;
 case 2:mapv(m,[&](V3 p,size_t){V3 x=q(p);float a=A*.22f*x.x,co=cosf(a),si=sinf(a);return C+V3{x.x,x.y*co-x.z*si,x.y*si+x.z*co};});break;
 case 3:mapv(m,[&](V3 p,size_t){V3 x=q(p);float z=std::max(.05f,1+A*.12f*x.y);x.x*=z;x.z*=z;return C+x;});break;
 case 4:mapv(m,[&](V3 p,size_t){return C+q(p)*(1+A*.18f*sinf(t*2));});break;
 case 5:mapv(m,[&](V3 p,size_t){V3 x=q(p);float r=len(x);return p+norm(x)*(A*.16f*sinf(r*5-t*3));});break;
 case 6:mapv(m,[&](V3 p,size_t i){return p+V3{A*.12f*rnd(c.seed+i*3),A*.12f*rnd(c.seed+i*3+1),A*.12f*rnd(c.seed+i*3+2)};});break;
 case 7:mapv(m,[&](V3 p,size_t){float z=std::max(.03f,.25f/std::max(.1f,fabsf(A)));return V3{roundf(p.x/z)*z,roundf(p.y/z)*z,roundf(p.z/z)*z};});break;
 case 8:mapv(m,[&](V3 p,size_t){V3 x=q(p);x.x=fabsf(x.x);if(fabsf(A)>1)x.z=fabsf(x.z);return C+x;});break;
 case 9:mapv(m,[&](V3 p,size_t){V3 x=q(p);float u=clampf(fabsf(A),0,1);return C+x*(1-u)+norm(x)*(1.7f*u);});break;
 case 10:mapv(m,[&](V3 p,size_t){V3 x=q(p);float k=std::max({fabsf(x.x),fabsf(x.y),fabsf(x.z),1e-5f});return C+x*(1.7f/k);});break;
 case 11:mapv(m,[&](V3 p,size_t){V3 x=q(p);return C+x*((1.8f+.2f*A)/std::max(.08f,dot(x,x)));});break;
 case 12:mapv(m,[&](V3 p,size_t){V3 x=q(p);float r=hypotf(x.x,x.z),a=A*1.4f/(.35f+r)+t*.2f,co=cosf(a),si=sinf(a);return C+V3{x.x*co-x.z*si,x.y,x.x*si+x.z*co};});break;
 case 13:mapv(m,[&](V3 p,size_t){p.x+=A*.3f*sinf(p.y*2.7f+t);p.z+=A*.2f*cosf(p.x*2.1f-t);return p;});break;
 case 14:mapv(m,[&](V3 p,size_t){V3 x=q(p);return C+x*(1+A*.12f*sinf(len(x)*6-t*2));});break;
 case 15:mapv(m,[&](V3 p,size_t){return A>=0?V3{p.y,p.z,p.x}:V3{p.z,p.x,p.y};});break;
 case 16:mapv(m,[&](V3 p,size_t){V3 x=q(p);float a=atan2f(x.z,x.x)*.5f*A,co=cosf(a),si=sinf(a);return C+V3{x.x,x.y*co-x.z*si,x.y*si+x.z*co};});break;
 case 17:mapv(m,[&](V3 p,size_t){V3 x=q(p);float r=hypotf(x.x,x.z),a=atan2f(x.z,x.x),sg=PI/3;a=fabsf(fmodf(a+PI,sg)-sg*.5f);return C+V3{r*cosf(a),x.y,r*sinf(a)};});break;
 case 18:mapv(m,[&](V3 p,size_t){V3 x=q(p);float r=hypotf(x.x,x.z),a=atan2f(x.z,x.x),sg=PI/8;a=roundf(a/sg)*sg;return C+V3{r*cosf(a),x.y,r*sinf(a)};});break;
 case 19:mapv(m,[&](V3 p,size_t){V3 x=q(p);return C+x*(1+A*.2f*sinf(t*1.7f+atan2f(x.z,x.x)*3));});break;
 case 20:mapv(m,[&](V3 p,size_t){V3 x=q(p);float z=1-A*.55f*expf(-x.y*x.y);x.x*=z;x.z*=z;return C+x;});break;
 case 21:mapv(m,[&](V3 p,size_t i){return p+norm(q(p))*(A*.45f*(.5f+.5f*rnd(c.seed+(uint32_t)i)));});break;
 case 22:mapv(m,[&](V3 p,size_t){return C+q(p)*std::max(.02f,1-.35f*fabsf(A));});break;
 case 23:mapv(m,[&](V3 p,size_t i){uint32_t k=c.seed+(uint32_t)i+(uint32_t)floorf(t*3)*101u;return p+V3{A*.22f*rnd(k),A*.22f*rnd(k+7),A*.22f*rnd(k+19)};});break;
 case 24:mapv(m,[&](V3 p,size_t i){return C+q(p)*(1+A*.14f*sinf(t*4+float(i)*.17f));});break;
 case 25:cull(m,[&](V3 a,V3 b,size_t){float y=(sinf(t)*.5f+.5f)*4-2;return fabsf((a.y+b.y)*.5f-y)<.45f;});break;
 case 26:cull(m,[&](V3 a,V3 b,size_t){return fmodf(fabsf((a.y+b.y)*2+t),2)<1;});break;
 case 27:cull(m,[&](V3 a,V3 b,size_t){V3 p=(a+b)*.5f;return (((int)floorf(p.x*2)+(int)floorf(p.y*2)+(int)floorf(p.z*2))&1)!=0;});break;
 case 28:cull(m,[&](V3 a,V3 b,size_t){return fmodf(len(q((a+b)*.5f))*3+t,2)<1;});break;
 case 29:cull(m,[&](V3 a,V3 b,size_t){return (a.z+b.z)*.5f>C.z+A*.2f*sinf(t);});break;
 case 30:cull(m,[&](V3,V3,size_t e){return sinf(float(e)*.73f+t*3)>-.1f;});break;
 case 31:{Mesh x=m;for(int k=1;k<=4;k++)copy(m,x,{0,.08f*k,0},1-.08f*k,.13f*k+A*.03f);}break;
 case 32:{Mesh x=m;for(int k=1;k<6;k++){float a=t*.3f+k*2*PI/6;copy(m,x,{1.8f*cosf(a),0,1.8f*sinf(a)},.35f,a);}}break;
 case 33:{Mesh x=m;for(int k=1;k<=4;k++)copy(m,x,{0,0,0},powf(.55f,k),t*.1f*k);}break;
 case 34:{Mesh x=m;for(int k=1;k<=6;k++)copy(m,x,{-.12f*k,.04f*k,.08f*k},1-.09f*k,-.06f*k);}break;
 case 35:mapv(m,[&](V3 p,size_t i){float ph=t+float(i%97)*.025f;p.x+=A*.18f*sinf(ph+p.y);p.z+=A*.18f*cosf(ph-p.x);return p;});break;
 case 36:if(s&&!s->v.empty()){unsigned base=(unsigned)m.v.size();m.v.insert(m.v.end(),s->v.begin(),s->v.end());for(auto i:s->e)m.e.push_back(base+i);size_t n=std::min<size_t>(64,std::min<size_t>(base,s->v.size()));for(size_t i=0;i<n;i++)m.e.insert(m.e.end(),{(unsigned)(i*base/n),base+(unsigned)(i*s->v.size()/n)});}break;
 case 37:if(s&&!s->v.empty()){unsigned base=(unsigned)m.v.size();m.v.insert(m.v.end(),s->v.begin(),s->v.end());for(auto i:s->e)m.e.push_back(base+i);for(unsigned i=0;i<base;i+=std::max(1u,base/48u)){float bd=1e30f;unsigned bj=0;for(unsigned j=0;j<s->v.size();j++){float d=len(m.v[i]-s->v[j]);if(d<bd){bd=d;bj=j;}}m.e.insert(m.e.end(),{i,base+bj});}}break;
 case 38:{unsigned cc=(unsigned)m.v.size();m.v.push_back(C);for(unsigned i=0;i<cc;i+=std::max(1u,cc/96u))m.e.insert(m.e.end(),{cc,i});}break;
 case 39:{unsigned n=(unsigned)m.v.size();for(unsigned i=0;i<n;i+=std::max(1u,n/80u)){unsigned j=(i*37+17)%n;if(i!=j)m.e.insert(m.e.end(),{i,j});}}break;
 case 40:subdiv(m,3,0,c.seed);break;case 41:subdiv(m,4,.09f*fabsf(A),c.seed);break;case 42:subdiv(m,5,.05f*(1+fabsf(A)),c.seed+31);break;case 43:subdiv(m,6,.15f*fabsf(A),c.seed+(uint32_t)(t*8));break;
 case 44:mapv(m,[&](V3 p,size_t){V3 x=q(p);float r=std::max(.15f,hypotf(x.x,x.y)),f=A*.35f/(r*r+.2f);x.x*=1+f;x.y*=1+f;return C+x;});break;
 case 45:mapv(m,[&](V3 p,size_t){V3 x=q(p);float r=std::max(.1f,hypotf(x.x,x.z)),a=A*.6f/(r+.1f),co=cosf(a),si=sinf(a);return C+V3{x.x*co-x.z*si,x.y/(1+.2f/r),x.x*si+x.z*co};});break;
 case 46:mapv(m,[&](V3 p,size_t){for(float sx:{-1.f,1.f}){V3 h{C.x+sx*1.1f,C.y,C.z},d=p-h;float r=len(d);if(r<1.2f)p=p+norm(d)*(A*.16f*(1.2f-r));}return p;});break;
 case 47:cull(m,[&](V3 a,V3 b,size_t){return len(q((a+b)*.5f))>.65f+.15f*sinf(t);});break;
 case 48:mapv(m,[&](V3 p,size_t){p.x+=A*.35f*sinf(p.y*p.y*2+t);p.z+=A*.22f*sinf(p.x*3-p.y*2);return p;});break;
 case 49:mapv(m,[&](V3 p,size_t){float d=1+A*.16f*p.z;if(fabsf(d)<.12f)d=d<0?-.12f:.12f;return V3{p.x/d,p.y/d,p.z};});break;
 case 50:mapv(m,[&](V3 p,size_t){float d=expf(clampf(A*.12f*p.z,-1.5f,1.5f));return V3{p.x*d,p.y*d,p.z};});break;
 case 51:mapv(m,[&](V3 p,size_t){V3 x=q(p);float r=len(x);return C+x*((1+A*.12f*r*r)/(1+.04f*r*r));});break;
 case 52:{Mesh x=m;mapv(m,[&](V3 p,size_t){p.x-=.08f*A;return p;});copy(m,x,{.16f*A,0,0},1,0);}break;
 case 53:{Mesh x=m;copy(m,x,{.04f*A,0,0},1.01f,.012f*A);copy(m,x,{-.04f*A,0,0},.99f,-.012f*A);}break;
 case 54:mapv(m,[&](V3 p,size_t){return C+q(p)*(1+A*.35f*c.bass);});break;
 case 55:{EffectContext x=c;x.amount=A*(.2f+2*c.mid);return applyEffect(m,1,x,s);}case 56:mapv(m,[&](V3 p,size_t){float f=p.y>C.y?c.treble:c.bass;return C+q(p)*(1+A*.25f*f);});break;
 case 57:if(c.beat>.4f){EffectContext x=c;x.amount=A*c.beat;return applyEffect(m,23,x,s);}break;
 case 58:mapv(m,[&](V3 p,size_t){return C+q(p)*(1+A*.3f*c.bass*sinf(t*2));});break;
 case 59:{EffectContext x=c;x.amount=A*c.treble;return applyEffect(m,6,x,s);}case 60:mapv(m,[&](V3 p,size_t){V3 x=q(p);float a=atan2f(x.z,x.x),f=c.bass*sinf(a*3)+c.mid*sinf(a*7)+c.treble*sinf(a*13);return C+x*(1+A*.12f*f);});break;
 case 61:mapv(m,[&](V3 p,size_t){V3 v{sinf(p.y+t)-cosf(p.z),sinf(p.z-t)-cosf(p.x),sinf(p.x+t)-cosf(p.y)};return p+v*(A*.12f);});break;
 case 62:mapv(m,[&](V3 p,size_t){V3 v{cosf(p.y)-sinf(p.z),cosf(p.z)-sinf(p.x),cosf(p.x)-sinf(p.y)};return p+v*(A*.16f);});break;
 case 63:mapv(m,[&](V3 p,size_t){p.x+=A*.2f*sinf(p.y*2+sinf(p.z*3+t));p.y+=A*.2f*sinf(p.z*2+sinf(p.x*3-t));p.z+=A*.2f*sinf(p.x*2+sinf(p.y*3+t));return p;});break;}
 sanitize(m);if(m.e.empty())m=std::move(original);const char*why=nullptr;return validateMesh(m,&why);
}
