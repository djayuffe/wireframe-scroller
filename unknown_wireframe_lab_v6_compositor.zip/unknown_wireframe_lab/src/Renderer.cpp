#include "Renderer.hpp"
#ifdef __APPLE__
#include <OpenGL/gl3.h>
#else
#include <GL/gl.h>
#endif
#include <cstdio>
#include <limits>
static const char*VS=R"(#version 330 core
layout(location=0) in vec3 P; uniform mat4 MVP; uniform float T; out float fade;
void main(){vec4 q=MVP*vec4(P,1.0);gl_Position=q;float z=abs(q.z/max(abs(q.w),1e-5));fade=clamp(1.08-z*.13,0.20,1.0);})";
static const char*FS=R"(#version 330 core
in float fade;uniform float T;out vec4 C;void main(){float p=.90+.10*sin(T*1.7);vec3 c=vec3(.48,.80,1.0)*fade*p;C=vec4(c,.35+.65*fade);})";
static unsigned compileShader(unsigned type,const char*s){unsigned x=glCreateShader(type);if(!x)return 0;glShaderSource(x,1,&s,nullptr);glCompileShader(x);int ok=0;glGetShaderiv(x,GL_COMPILE_STATUS,&ok);if(!ok){char b[4096]{};glGetShaderInfoLog(x,sizeof b,nullptr,b);std::fprintf(stderr,"shader compile failed: %s\n",b);glDeleteShader(x);return 0;}return x;}
void Renderer::reset() noexcept{if(ebo)glDeleteBuffers(1,&ebo);if(vbo)glDeleteBuffers(1,&vbo);if(vao)glDeleteVertexArrays(1,&vao);if(prog)glDeleteProgram(prog);ebo=vbo=vao=prog=0;mvpLoc=timeLoc=-1;}
bool Renderer::init(){reset();unsigned a=compileShader(GL_VERTEX_SHADER,VS),b=compileShader(GL_FRAGMENT_SHADER,FS);if(!a||!b){if(a)glDeleteShader(a);if(b)glDeleteShader(b);return false;}prog=glCreateProgram();if(!prog){glDeleteShader(a);glDeleteShader(b);return false;}glAttachShader(prog,a);glAttachShader(prog,b);glLinkProgram(prog);glDeleteShader(a);glDeleteShader(b);int ok=0;glGetProgramiv(prog,GL_LINK_STATUS,&ok);if(!ok){char s[4096]{};glGetProgramInfoLog(prog,sizeof s,nullptr,s);std::fprintf(stderr,"program link failed: %s\n",s);reset();return false;}mvpLoc=glGetUniformLocation(prog,"MVP");timeLoc=glGetUniformLocation(prog,"T");glGenVertexArrays(1,&vao);glGenBuffers(1,&vbo);glGenBuffers(1,&ebo);if(!vao||!vbo||!ebo||mvpLoc<0||timeLoc<0){reset();return false;}glBindVertexArray(vao);glBindBuffer(GL_ARRAY_BUFFER,vbo);glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,sizeof(V3),nullptr);glEnableVertexAttribArray(0);glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,ebo);glBindVertexArray(0);return true;}
void Renderer::draw(const Mesh&m,const M4&vp,float t){if(!prog||m.v.empty()||m.e.empty()||m.e.size()>static_cast<size_t>(std::numeric_limits<GLsizei>::max()))return;glUseProgram(prog);glUniformMatrix4fv(mvpLoc,1,GL_FALSE,vp.m);glUniform1f(timeLoc,t);glBindVertexArray(vao);glBindBuffer(GL_ARRAY_BUFFER,vbo);glBufferData(GL_ARRAY_BUFFER,(GLsizeiptr)(m.v.size()*sizeof(V3)),m.v.data(),GL_STREAM_DRAW);glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,ebo);glBufferData(GL_ELEMENT_ARRAY_BUFFER,(GLsizeiptr)(m.e.size()*sizeof(unsigned)),m.e.data(),GL_STREAM_DRAW);glDrawElements(GL_LINES,(GLsizei)m.e.size(),GL_UNSIGNED_INT,nullptr);glBindVertexArray(0);glUseProgram(0);}
Renderer::~Renderer(){reset();}
