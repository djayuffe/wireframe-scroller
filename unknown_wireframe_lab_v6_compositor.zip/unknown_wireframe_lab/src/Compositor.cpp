#include "Compositor.hpp"
#include <algorithm>
static int wrap(int x,int n){x%=n;return x<0?x+n:x;}
static EffectStage S(int fx,float a,float ts=1,float to=0,uint32_t so=0,bool sec=false){return {fx,a,ts,to,so,sec};}
EffectRecipe recipe(int id){
  id=wrap(id,recipeCount()); EffectRecipe r{};
  auto set=[&](std::string_view n,std::initializer_list<EffectStage> s){r.name=n;r.stageCount=std::min<int>(6,s.size());int i=0;for(auto &x:s)if(i<6)r.stages[i++]=x;};
  switch(id){
   case 0:set("Raw",{});break;
   case 1:set("Singularity Bloom",{S(11,.8f),S(50,.55f),S(5,.45f),S(32,.7f)});break;
   case 2:set("Impossible Cathedral",{S(17,1),S(12,.7f),S(48,.65f),S(39,.45f)});break;
   case 3:set("Quantum Shatter",{S(23,.7f),S(43,.7f),S(35,.55f),S(6,.2f)});break;
   case 4:set("Hyper Echo",{S(51,.7f),S(34,.75f),S(13,.55f),S(5,.25f)});break;
   case 5:set("Wormhole Lattice",{S(47,.9f),S(18,.8f),S(38,.6f),S(33,.35f)});break;
   case 6:set("Spectral Organism",{S(62,.8f),S(60,1),S(15,.4f),S(31,.45f)});break;
   case 7:set("Topology Storm",{S(22,.65f),S(42,.5f),S(29,.8f),S(36,.7f,1,0,0,true)});break;
   case 8:set("Recursive Reactor",{S(33,.7f),S(44,.45f),S(10,.5f),S(4,.4f)});break;
   case 9:set("Kaleido Collapse",{S(17,1),S(20,.8f),S(25,.7f),S(13,.5f)});break;
   case 10:set("Black Star",{S(46,.9f),S(49,.7f),S(28,.8f),S(43,.35f)});break;
   case 11:set("Interference Bridge",{S(37,.8f,1,0,0,true),S(61,.55f),S(14,.35f),S(32,.3f)});break;
   case 12:set("Crystal Fracture",{S(7,.8f),S(42,.7f),S(17,.7f),S(6,.12f)});break;
   case 13:set("Mobius Lightning",{S(16,.8f),S(43,.6f),S(13,.5f),S(34,.3f)});break;
   case 14:set("Event Scanner",{S(49,.7f),S(25,.8f),S(14,.55f),S(35,.3f)});break;
   case 15:set("Dark Matter Flower",{S(45,.65f),S(19,.75f),S(63,.55f),S(39,.35f)});break;
   case 16:set("Projective Failure",{S(50,.9f),S(48,.7f),S(9,.45f),S(30,.5f)});break;
   case 17:set("Recursive Constellation",{S(33,.65f),S(39,.8f),S(5,.25f),S(14,.4f)});break;
   case 18:set("Alien Transmission",{S(55,.8f),S(60,.8f),S(26,.7f),S(44,.35f)});break;
   case 19:set("Fractal Orbit",{S(32,.55f),S(33,.5f),S(12,.4f),S(4,.25f)});break;
   case 20:set("Dual Singularity",{S(36,.65f,1,0,0,true),S(47,.75f),S(50,.5f),S(34,.25f)});break;
   case 21:set("Wireframe Supernova",{S(21,.65f),S(43,.5f),S(32,.5f),S(19,.35f)});break;
   case 22:set("Quasicrystal Ghost",{S(63,.7f),S(34,.6f),S(17,.55f),S(27,.45f)});break;
   default:set("Dimensional Infection",{S(61,.55f),S(16,.5f),S(42,.45f),S(50,.4f),S(32,.3f)});break;
  } return r;
}
std::string_view recipeName(int id){return recipe(id).name;}
static uint32_t h(uint32_t x){x^=x>>16;x*=0x7feb352dU;x^=x>>15;x*=0x846ca68bU;x^=x>>16;return x;}
EffectRecipe mutateRecipe(uint32_t seed,int depth){EffectRecipe r{};r.name="Mutation";r.stageCount=std::clamp(depth,1,6);uint32_t x=seed;for(int i=0;i<r.stageCount;i++){x=h(x+0x9e3779b9u+i);int fx=1+(x%(effectCount()-1));float a=.2f+((x>>8)&255)/255.f*.8f;float ts=.55f+((x>>16)&255)/255.f*1.4f;float off=((x>>24)&255)/255.f*3.14159f;r.stages[i]=S(fx,a,ts,off,x,(fx==36||fx==37));}return r;}
bool applyRecipe(Mesh&m,const EffectRecipe&r,const EffectContext&base,const Mesh*secondary){
 for(int i=0;i<std::clamp(r.stageCount,0,6);i++){auto s=r.stages[i];EffectContext c=base;c.time=base.time*s.timeScale+s.timeOffset;c.amount=base.amount*s.amount;c.seed=base.seed+s.seedOffset;if(!applyEffect(m,s.effect,c,s.useSecondary?secondary:nullptr))return false;}return true;
}
