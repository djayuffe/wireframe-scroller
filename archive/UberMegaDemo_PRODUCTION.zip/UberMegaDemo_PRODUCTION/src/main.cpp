#include <glad/gl.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/constants.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <chrono>
#include <random>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
#include <tuple>
#include <unordered_map>

struct Vertex { glm::vec3 p,n; glm::vec2 uv; };
struct Mesh { GLuint vao=0,vbo=0,ebo=0; GLsizei count=0; };
struct RT { GLuint fbo=0, color[2]{}, depth=0; int w=0,h=0; };
struct PP { GLuint fbo[2]{}, tex[2]{}; int w=0,h=0; };
static int W=1600,H=900; static bool paused=false; static float exposure=1.05f;
static int winX=100,winY=100,winW=1600,winH=900; static bool fullscreen=false; static bool requestReload=false,requestShot=false;

static std::filesystem::path assetRoot(){
    if(const char* e=std::getenv("UMD_ASSET_ROOT")) return std::filesystem::path(e);
    std::array<std::filesystem::path,5> roots={std::filesystem::current_path(),std::filesystem::current_path()/"..",std::filesystem::current_path()/"../..",std::filesystem::path("."),std::filesystem::path("..")} ;
    for(const auto&r:roots) if(std::filesystem::exists(r/"shaders/scene.vert")) return std::filesystem::weakly_canonical(r);
    return std::filesystem::current_path();
}
static std::string slurp(const std::filesystem::path& p){auto q=p.is_absolute()?p:assetRoot()/p;std::ifstream f(q);if(!f)throw std::runtime_error("Cannot open "+q.string());std::stringstream s;s<<f.rdbuf();return s.str();}
static GLuint shader(GLenum t,const std::string&s){GLuint x=glCreateShader(t);const char*p=s.c_str();glShaderSource(x,1,&p,nullptr);glCompileShader(x);GLint ok;glGetShaderiv(x,GL_COMPILE_STATUS,&ok);if(!ok){GLint n;glGetShaderiv(x,GL_INFO_LOG_LENGTH,&n);std::string l(n,' ');glGetShaderInfoLog(x,n,nullptr,l.data());throw std::runtime_error(l);}return x;}
static GLuint prog(const char*vs,const char*fs){auto v=shader(GL_VERTEX_SHADER,slurp(vs)),f=shader(GL_FRAGMENT_SHADER,slurp(fs));GLuint p=glCreateProgram();glAttachShader(p,v);glAttachShader(p,f);glLinkProgram(p);glDeleteShader(v);glDeleteShader(f);GLint ok;glGetProgramiv(p,GL_LINK_STATUS,&ok);if(!ok){GLint n;glGetProgramiv(p,GL_INFO_LOG_LENGTH,&n);std::string l(n,' ');glGetProgramInfoLog(p,n,nullptr,l.data());throw std::runtime_error(l);}return p;}
static Mesh upload(const std::vector<Vertex>&v,const std::vector<unsigned>&i){Mesh m;m.count=(GLsizei)i.size();glGenVertexArrays(1,&m.vao);glGenBuffers(1,&m.vbo);glGenBuffers(1,&m.ebo);glBindVertexArray(m.vao);glBindBuffer(GL_ARRAY_BUFFER,m.vbo);glBufferData(GL_ARRAY_BUFFER,v.size()*sizeof(Vertex),v.data(),GL_STATIC_DRAW);glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,m.ebo);glBufferData(GL_ELEMENT_ARRAY_BUFFER,i.size()*sizeof(unsigned),i.data(),GL_STATIC_DRAW);glEnableVertexAttribArray(0);glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,sizeof(Vertex),(void*)offsetof(Vertex,p));glEnableVertexAttribArray(1);glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,sizeof(Vertex),(void*)offsetof(Vertex,n));glEnableVertexAttribArray(2);glVertexAttribPointer(2,2,GL_FLOAT,GL_FALSE,sizeof(Vertex),(void*)offsetof(Vertex,uv));glBindVertexArray(0);return m;}
static Mesh cube(){std::vector<Vertex>v;std::vector<unsigned>i;glm::vec3 c[8]={{-1,-1,-1},{1,-1,-1},{1,1,-1},{-1,1,-1},{-1,-1,1},{1,-1,1},{1,1,1},{-1,1,1}};unsigned f[6][4]={{1,5,6,2},{4,0,3,7},{3,2,6,7},{4,5,1,0},{5,4,7,6},{0,1,2,3}};glm::vec3 n[6]={{1,0,0},{-1,0,0},{0,1,0},{0,-1,0},{0,0,1},{0,0,-1}};glm::vec2 u[4]={{0,0},{1,0},{1,1},{0,1}};for(int a=0;a<6;a++){unsigned b=v.size();for(int q=0;q<4;q++)v.push_back({c[f[a][q]],n[a],u[q]});i.insert(i.end(),{b,b+1,b+2,b,b+2,b+3});}return upload(v,i);}
static Mesh torus(int A=128,int B=20,float R=1,float r=.045f){std::vector<Vertex>v;std::vector<unsigned>i;for(int a=0;a<=A;a++){float x=float(a)/A*glm::two_pi<float>();for(int b=0;b<=B;b++){float y=float(b)/B*glm::two_pi<float>();glm::vec3 n={cos(x)*cos(y),sin(y),sin(x)*cos(y)};glm::vec3 c={cos(x)*R,0,sin(x)*R};v.push_back({c+n*r,n,{float(a)/A,float(b)/B}});}}int s=B+1;for(int a=0;a<A;a++)for(int b=0;b<B;b++){unsigned q=a*s+b;i.insert(i.end(),{q,q+s,q+1,q+1,q+s,q+s+1});}return upload(v,i);}
static Mesh quad(){return upload({{{-1,-1,0},{0,0,1},{0,0}},{{1,-1,0},{0,0,1},{1,0}},{{1,1,0},{0,0,1},{1,1}},{{-1,1,0},{0,0,1},{0,1}}},{0,1,2,0,2,3});}
static Mesh sphere(int A=64,int B=32){std::vector<Vertex>v;std::vector<unsigned>i;for(int y=0;y<=B;y++){float fy=float(y)/B,ph=fy*glm::pi<float>();for(int x=0;x<=A;x++){float fx=float(x)/A,th=fx*glm::two_pi<float>();glm::vec3 n={sin(ph)*cos(th),cos(ph),sin(ph)*sin(th)};v.push_back({n,n,{fx,fy}});}}int s=A+1;for(int y=0;y<B;y++)for(int x=0;x<A;x++){unsigned a=y*s+x,b=a+1,c=a+s,d=c+1;i.insert(i.end(),{a,c,b,b,c,d});}return upload(v,i);}
static Mesh cylinder(int N=48){std::vector<Vertex>v;std::vector<unsigned>i;for(int k=0;k<=N;k++){float a=float(k)/N*glm::two_pi<float>();glm::vec3 n={cos(a),0,sin(a)};v.push_back({{n.x,-1,n.z},n,{float(k)/N,0}});v.push_back({{n.x,1,n.z},n,{float(k)/N,1}});}for(int k=0;k<N;k++){unsigned a=k*2;i.insert(i.end(),{a,a+2,a+1,a+1,a+2,a+3});}return upload(v,i);}
static void destroy(Mesh&m){if(m.ebo)glDeleteBuffers(1,&m.ebo);if(m.vbo)glDeleteBuffers(1,&m.vbo);if(m.vao)glDeleteVertexArrays(1,&m.vao);m={};}
static void destroy(RT&r){if(r.depth)glDeleteRenderbuffers(1,&r.depth);glDeleteTextures(2,r.color);if(r.fbo)glDeleteFramebuffers(1,&r.fbo);r={};}
static void destroy(PP&p){glDeleteTextures(2,p.tex);glDeleteFramebuffers(2,p.fbo);p={};}

static std::unordered_map<std::string,GLint> uniformCache;
static GLint U(GLuint p,const char*n){std::string k=std::to_string(p)+":"+n;auto it=uniformCache.find(k);if(it!=uniformCache.end())return it->second;GLint loc=glGetUniformLocation(p,n);uniformCache.emplace(std::move(k),loc);return loc;}
static void clearUniformCache(){uniformCache.clear();} static void M(GLuint p,const char*n,const glm::mat4&m){glUniformMatrix4fv(U(p,n),1,GL_FALSE,glm::value_ptr(m));} static void V(GLuint p,const char*n,glm::vec3 v){glUniform3fv(U(p,n),1,glm::value_ptr(v));}
static glm::mat4 T(glm::vec3 p,glm::vec3 s,glm::vec3 r={0,0,0}){glm::mat4 m(1);m=glm::translate(m,p);m=glm::rotate(m,r.x,{1,0,0});m=glm::rotate(m,r.y,{0,1,0});m=glm::rotate(m,r.z,{0,0,1});return glm::scale(m,s);}
static void draw(GLuint p,const Mesh&m,const glm::mat4&t,glm::vec3 base,glm::vec3 emit,float metal=.9f,float rough=.25f){M(p,"uModel",t);V(p,"uBaseColor",base);V(p,"uEmission",emit);glUniform1f(U(p,"uMetallic"),metal);glUniform1f(U(p,"uRoughness"),rough);glBindVertexArray(m.vao);glDrawElements(GL_TRIANGLES,m.count,GL_UNSIGNED_INT,nullptr);}
static RT mkRT(int w,int h){RT r;r.w=w;r.h=h;glGenFramebuffers(1,&r.fbo);glBindFramebuffer(GL_FRAMEBUFFER,r.fbo);glGenTextures(2,r.color);for(int k=0;k<2;k++){glBindTexture(GL_TEXTURE_2D,r.color[k]);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA16F,w,h,0,GL_RGBA,GL_FLOAT,nullptr);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0+k,GL_TEXTURE_2D,r.color[k],0);}glGenRenderbuffers(1,&r.depth);glBindRenderbuffer(GL_RENDERBUFFER,r.depth);glRenderbufferStorage(GL_RENDERBUFFER,GL_DEPTH_COMPONENT24,w,h);glFramebufferRenderbuffer(GL_FRAMEBUFFER,GL_DEPTH_ATTACHMENT,GL_RENDERBUFFER,r.depth);GLenum b[]={GL_COLOR_ATTACHMENT0,GL_COLOR_ATTACHMENT1};glDrawBuffers(2,b);if(glCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE)throw std::runtime_error("HDR FBO incomplete");glBindFramebuffer(GL_FRAMEBUFFER,0);return r;}
static PP mkPP(int w,int h){PP p;p.w=w;p.h=h;glGenFramebuffers(2,p.fbo);glGenTextures(2,p.tex);for(int k=0;k<2;k++){glBindFramebuffer(GL_FRAMEBUFFER,p.fbo[k]);glBindTexture(GL_TEXTURE_2D,p.tex[k]);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA16F,w,h,0,GL_RGBA,GL_FLOAT,nullptr);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,p.tex[k],0);if(glCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE)throw std::runtime_error("Bloom FBO incomplete");}glBindFramebuffer(GL_FRAMEBUFFER,0);return p;}
static void tri(GLuint p,const Mesh&b,glm::vec3 c,float R,float thick,float dep,glm::vec3 e){glm::vec2 x[3];for(int k=0;k<3;k++){float a=glm::half_pi<float>()+k*glm::two_pi<float>()/3.f;x[k]={cos(a)*R,sin(a)*R};}for(int k=0;k<3;k++){auto a=x[k],z=x[(k+1)%3],d=z-a,mid=(a+z)*.5f;draw(p,b,T(c+glm::vec3(mid,0),{glm::length(d)*.5f,thick,dep},{0,0,atan2(d.y,d.x)}),{.12f,.13f,.15f},e,.96f,.2f);}}
static void key(GLFWwindow*w,int key,int,int action,int){if(action!=GLFW_PRESS)return;if(key==GLFW_KEY_ESCAPE)glfwSetWindowShouldClose(w,1);if(key==GLFW_KEY_SPACE)paused=!paused;if(key==GLFW_KEY_UP)exposure=std::min(3.f,exposure+.1f);if(key==GLFW_KEY_DOWN)exposure=std::max(.1f,exposure-.1f);if(key==GLFW_KEY_R)requestReload=true;if(key==GLFW_KEY_F12)requestShot=true;if(key==GLFW_KEY_F11){fullscreen=!fullscreen;GLFWmonitor*m=glfwGetPrimaryMonitor();const GLFWvidmode*v=glfwGetVideoMode(m);if(fullscreen){glfwGetWindowPos(w,&winX,&winY);glfwGetWindowSize(w,&winW,&winH);glfwSetWindowMonitor(w,m,0,0,v->width,v->height,v->refreshRate);}else glfwSetWindowMonitor(w,nullptr,winX,winY,winW,winH,0);}}

static void screenshotPPM(int w,int h,int index){
    std::vector<unsigned char> px(size_t(w)*h*3), flipped(px.size());
    glPixelStorei(GL_PACK_ALIGNMENT,1); glReadPixels(0,0,w,h,GL_RGB,GL_UNSIGNED_BYTE,px.data());
    for(int y=0;y<h;y++) std::copy_n(px.data()+size_t(y)*w*3,size_t(w)*3,flipped.data()+size_t(h-1-y)*w*3);
    std::ostringstream name; name<<"capture_"<<std::setw(5)<<std::setfill('0')<<index<<".ppm";
    std::ofstream f(name.str(),std::ios::binary); f<<"P6\\n"<<w<<" "<<h<<"\\n255\\n"; f.write((char*)flipped.data(),std::streamsize(flipped.size()));
    std::cerr<<"Captured "<<name.str()<<"\\n";
}
static void debugInfo(){
    std::cerr<<"Vendor: "<<glGetString(GL_VENDOR)<<"\\nRenderer: "<<glGetString(GL_RENDERER)<<"\\nVersion: "<<glGetString(GL_VERSION)<<"\\nGLSL: "<<glGetString(GL_SHADING_LANGUAGE_VERSION)<<"\\n";
}
int main(){try{if(!glfwInit())throw std::runtime_error("glfwInit failed");glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR,4);glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR,1);glfwWindowHint(GLFW_OPENGL_PROFILE,GLFW_OPENGL_CORE_PROFILE);
#ifdef __APPLE__
glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT,GL_TRUE);
#endif
GLFWwindow*w=glfwCreateWindow(W,H,"UBER — OpenGL Mega Demo",nullptr,nullptr);if(!w)throw std::runtime_error("window failed");glfwMakeContextCurrent(w);glfwSwapInterval(1);glfwSetKeyCallback(w,key);if(!gladLoadGL(glfwGetProcAddress))throw std::runtime_error("GLAD failed");debugInfo();
GLuint scene=prog("shaders/scene.vert","shaders/scene.frag"),blur=prog("shaders/fullscreen.vert","shaders/blur.frag"),comp=prog("shaders/fullscreen.vert","shaders/composite.frag");Mesh box=cube(),ring=torus(),fs=quad(),orb=sphere(),beam=cylinder();RT rt=mkRT(W,H);PP pp=mkPP(W,H);glEnable(GL_DEPTH_TEST);glEnable(GL_CULL_FACE);double last=glfwGetTime(),sim=0,statT=last; unsigned long long frames=0; int shotIndex=0; bool deterministic=std::getenv("UMD_DETERMINISTIC")!=nullptr; double fixedDt=1.0/60.0;
while(!glfwWindowShouldClose(w)){glfwPollEvents();double now=glfwGetTime(),dt=deterministic?fixedDt:std::min(.05,now-last);last=now;if(!paused)sim+=dt;float t=(float)sim;int fw,fh;glfwGetFramebufferSize(w,&fw,&fh);if(fw<=0||fh<=0){glfwWaitEventsTimeout(0.05);continue;}if(fw>0&&fh>0&&(fw!=rt.w||fh!=rt.h)){destroy(rt);destroy(pp);rt=mkRT(fw,fh);pp=mkPP(fw,fh);}glm::vec3 eye={sin(t*.10f)*2.5f,2.5f+sin(t*.17f)*.25f,14.5f};auto view=glm::lookAt(eye,glm::vec3(0,3,-7),glm::vec3(0,1,0));auto pr=glm::perspective(glm::radians(58.f),float(rt.w)/rt.h,.1f,180.f);
glBindFramebuffer(GL_FRAMEBUFFER,rt.fbo);glViewport(0,0,rt.w,rt.h);glClearColor(.001f,.001f,.004f,1);glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);glUseProgram(scene);M(scene,"uView",view);M(scene,"uProjection",pr);V(scene,"uCamera",eye);V(scene,"uLightDir",glm::normalize(glm::vec3(-.3f,.75f,.45f)));glUniform1f(U(scene,"uTime"),t);
// reflective-looking floor slabs + runway
draw(scene,box,T({0,-1,-7},{18,.08f,30}),{.015f,.018f,.024f},{.008f,0,0},.98f,.08f);for(int x=-8;x<=8;x++)for(int z=0;z<18;z++)if((x+z)%2==0)draw(scene,box,T({x*2.f,-.89f,8-z*2.5f},{.92f,.015f,1.1f}),{.02f,.022f,.027f},{.012f,0,0},.98f,.12f);
// portal
tri(scene,box,{0,3,-8},6.1f,.25f,.55f,{2.5f,.002f,.001f});tri(scene,box,{0,3,-7.5f},4.7f,.14f,.34f,{6.f,.003f,.001f});tri(scene,box,{0,3,-7},2.9f,.08f,.22f,{12.f,.006f,.002f});float beat=.5f+.5f*sin(t*3.2f);beat=pow(beat,10.f);draw(scene,box,T({0,5,-7},{.045f,11,.045f}),{.1f,0,0},{6+12*beat,.01f,.002f},.1f,.03f);
// wings
for(int s:{-1,1})for(int i=0;i<7;i++){float x=s*(3.1f+i*1.55f),y=1.1f+i*.48f,z=-6-i*.7f;draw(scene,box,T({x,y,z},{1.9f,.22f,.52f},{0,s*.12f,s*.55f}),{.07f,.075f,.085f},{1.25f+.4f*beat,0,0},.97f,.23f);}
// skyline
for(int i=-12;i<=12;i++){if(i==0)continue;float h=4+7*std::abs(sin(i*2.117f));draw(scene,box,T({i*1.55f,h*.5f-1,-22},{.28f,h*.5f,.45f}),{.018f,.02f,.027f},{.15f+.1f*std::abs(sin(t+i)),0,0},.95f,.3f);}
// halo
for(int j=0;j<2;j++){glm::mat4 m(1);m=glm::translate(m,{0,8.5f+j*.35f,-18});m=glm::rotate(m,glm::radians(77.f+j*2.f),{1,0,0});m=glm::scale(m,glm::vec3(9.5f-j*.4f));draw(scene,ring,m,{.04f,.045f,.055f},{3.8f+j*1.5f,0,0},.85f,.12f);}
// procedural moon / singularity anchor
 draw(scene,orb,T({-10.5f,10.0f,-34.0f},{5.2f,5.2f,5.2f}),{.055f,.06f,.075f},{.02f,.005f,.003f},.15f,.78f);
 // energy conduits / volumetric-beam geometry proxies
 for(int s:{-1,1})for(int q=0;q<4;q++){float x=s*(2.2f+q*2.4f);draw(scene,beam,T({x,2.2f,-12.f-q*1.8f},{.035f,3.0f+q*.7f,.035f}),{.03f,.005f,.004f},{2.0f+.8f*beat,.01f,.003f},.2f,.08f);}
 // recursive portal frames: geometric depth recursion rather than only screen distortion
 for(int q=1;q<=7;q++){float z=-8.2f-q*1.55f,sc=pow(.78f,float(q));tri(scene,box,{0,3,z},2.7f*sc,.045f*sc,.12f,{4.5f/(q*.55f+1.f),.003f,.001f});}
 // impossible floating slabs, alternating orientation
 for(int q=0;q<18;q++){float a=q*glm::two_pi<float>()/18.f+t*.055f;float rr=6.8f+1.2f*sin(q*1.7f);glm::vec3 p={cos(a)*rr,3.5f+sin(a*3.f)*1.7f,-13.f+sin(a)*3.f};draw(scene,box,T(p,{1.2f,.08f,.38f},{sin(a)*.4f,a,cos(a)*.7f}),{.035f,.04f,.052f},{.4f+.9f*beat,0,0},.96f,.18f);}

// floating discs
for(int s:{-1,1})for(int j=0;j<3;j++){glm::mat4 m(1);m=glm::translate(m,{s*(8.f+j*3.5f),3.5f+j*1.8f,-10.f-j*2});m=glm::rotate(m,glm::radians(90.f),{1,0,0});m=glm::scale(m,glm::vec3(1.8f+j*.25f));draw(scene,ring,m,{.035f,.04f,.05f},{1.6f+.7f*beat,0,0},.9f,.14f);}
// runway and side lamps
for(int i=0;i<26;i++){float z=8-i*1.25f;float chase=pow(.5f+.5f*sin(t*5-i*.75f),14.f);draw(scene,box,T({0,-.88f,z},{.045f,.018f,.3f}),{.04f,0,0},{1.3f+8*chase,0,0},.1f,.03f);for(int s:{-1,1})draw(scene,box,T({s*(3.2f+i*.26f),-.87f,z},{.065f,.02f,.24f}),{.03f,0,0},{1.2f+.6f*chase,0,0},.1f,.03f);}
// debris pillars / sparks as tiny emissive boxes
for(int i=0;i<90;i++){float fi=float(i);float x=sin(fi*12.9898f)*11.f,y=.3f+fmod(fi*1.731f+t*(.3f+fmod(fi,5.f)*.05f),7.f),z=-4-fmod(fi*2.37f,18.f);float sz=.015f+.015f*fmod(fi,3.f);draw(scene,box,T({x,y,z},{sz,.08f+sz,sz}),{.03f,0,0},{2.5f,0.03f,0.005f},.1f,.05f);}
glBindFramebuffer(GL_FRAMEBUFFER,0);
// bloom
 glDisable(GL_DEPTH_TEST);glUseProgram(blur);glUniform1i(U(blur,"uImage"),0);bool horiz=true,first=true;int lastTex=0;for(int i=0;i<12;i++){int dst=horiz?1:0;glBindFramebuffer(GL_FRAMEBUFFER,pp.fbo[dst]);glViewport(0,0,pp.w,pp.h);glUniform1i(U(blur,"uHorizontal"),horiz);glActiveTexture(GL_TEXTURE0);glBindTexture(GL_TEXTURE_2D,first?rt.color[1]:pp.tex[lastTex]);glBindVertexArray(fs.vao);glDrawElements(GL_TRIANGLES,fs.count,GL_UNSIGNED_INT,nullptr);lastTex=dst;first=false;horiz=!horiz;}
// shader hot reload: compile new programs first, swap only on success
 if(requestReload){requestReload=false;try{GLuint ns=prog("shaders/scene.vert","shaders/scene.frag"),nb=prog("shaders/fullscreen.vert","shaders/blur.frag"),nc=prog("shaders/fullscreen.vert","shaders/composite.frag");glDeleteProgram(scene);glDeleteProgram(blur);glDeleteProgram(comp);scene=ns;blur=nb;comp=nc;clearUniformCache();std::cerr<<"Shaders reloaded\n";}catch(const std::exception&e){std::cerr<<"Reload rejected: "<<e.what()<<"\n";}}
// composite
 glBindFramebuffer(GL_FRAMEBUFFER,0);glViewport(0,0,fw,fh);glClear(GL_COLOR_BUFFER_BIT);glUseProgram(comp);glUniform1i(U(comp,"uScene"),0);glUniform1i(U(comp,"uBloom"),1);glUniform1f(U(comp,"uTime"),t);glUniform1f(U(comp,"uExposure"),exposure);glActiveTexture(GL_TEXTURE0);glBindTexture(GL_TEXTURE_2D,rt.color[0]);glActiveTexture(GL_TEXTURE1);glBindTexture(GL_TEXTURE_2D,pp.tex[lastTex]);glBindVertexArray(fs.vao);glDrawElements(GL_TRIANGLES,fs.count,GL_UNSIGNED_INT,nullptr);glEnable(GL_DEPTH_TEST);
 if(requestShot){requestShot=false;screenshotPPM(fw,fh,shotIndex++);}
 glfwSwapBuffers(w); frames++; if(now-statT>=1.0){double fps=frames/(now-statT);std::ostringstream title;title<<"UBER — OpenGL Mega Demo | "<<std::fixed<<std::setprecision(1)<<fps<<" FPS | "<<rt.w<<"x"<<rt.h<<" | t="<<std::setprecision(2)<<sim;glfwSetWindowTitle(w,title.str().c_str());frames=0;statT=now;}
}destroy(box);destroy(ring);destroy(fs);destroy(orb);destroy(beam);destroy(rt);destroy(pp);glDeleteProgram(scene);glDeleteProgram(blur);glDeleteProgram(comp);glfwDestroyWindow(w);glfwTerminate();return 0;}catch(const std::exception&e){std::cerr<<"FATAL: "<<e.what()<<"\n";glfwTerminate();return 1;}}
