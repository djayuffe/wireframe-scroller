# Continuation audit

## Added and wired
- Transactional GLSL hot reload (`R`).
- Final-frame capture (`F12`) without another image dependency; binary PPM output is deterministic and trivial to convert.
- Fixed-step deterministic playback using `UMD_DETERMINISTIC=1`.
- Runtime FPS/resolution/timeline instrumentation.
- GL vendor/renderer/version/GLSL startup diagnostics.
- Uniform-location cache to eliminate repeated driver string lookups from every draw call.

## Re-audited invariants
- HDR and bloom targets recreate at framebuffer pixel size, not logical window size.
- Zero-size/minimized windows never allocate 0x0 render targets.
- Shader reload is fail-safe: compile/link failure leaves the previous programs alive.
- Capture occurs after the final composite and before swap, so it records the displayed post-processed frame.
- Timeline clamps interactive frame deltas; deterministic mode ignores wall-clock jitter.

## Remaining architectural ceiling
The renderer deliberately targets OpenGL 4.1 Core for macOS. Compute-shader particle/fluid pipelines, SSBO-driven indirect drawing and modern bindless techniques are therefore not used. CPU submission remains appropriate for the current scene scale; a future Metal/Vulkan branch would be the correct place for those APIs rather than pretending they exist in GL 4.1.
