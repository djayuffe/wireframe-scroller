#version 410 core
in vec2 vUV;out vec4 FragColor;uniform sampler2D uImage;uniform bool uHorizontal;void main(){vec2 t=1./vec2(textureSize(uImage,0));float w[5]=float[](.227027,.1945946,.1216216,.054054,.016216);vec3 c=texture(uImage,vUV).rgb*w[0];for(int i=1;i<5;i++){vec2 o=uHorizontal?vec2(t.x*i,0):vec2(0,t.y*i);c+=(texture(uImage,vUV+o).rgb+texture(uImage,vUV-o).rgb)*w[i];}FragColor=vec4(c,1);}
