#version 410 core
in vec2 vUV; out vec4 FragColor;
uniform sampler2D uScene; uniform sampler2D uBloom; uniform float uExposure; uniform float uTime;
float hash21(vec2 p){p=fract(p*vec2(123.34,456.21));p+=dot(p,p+45.32);return fract(p.x*p.y);}
vec3 aces(vec3 x){float a=2.51,b=.03,c=2.43,d=.59,e=.14;return clamp((x*(a*x+b))/(x*(c*x+d)+e),0.,1.);}
float beat(float t,float f){return pow(.5+.5*sin(t*f),18.);}
vec2 barrel(vec2 uv,float k){vec2 p=uv-.5;float r2=dot(p,p);return .5+p*(1.+k*r2);}
vec2 kaleido(vec2 uv,float n,float amt){vec2 p=uv-.5;float r=length(p),a=atan(p.y,p.x);float s=6.2831853/n;a=abs(mod(a+s*.5,s)-s*.5);vec2 q=vec2(cos(a),sin(a))*r+.5;return mix(uv,q,amt);}
void main(){
 float t=uTime, cycle=mod(t,48.0), pulse=beat(t,3.2); vec2 uv=vUV,p=uv-.5; float r=length(p);
 // Timeline: architecture -> impossible portal -> hyperspace -> lens collapse -> rebuild.
 float kAmt=smoothstep(10.,15.,cycle)*(1.-smoothstep(21.,25.,cycle)); uv=kaleido(uv,3.+floor(mod(cycle,4.)),kAmt*.72);
 float tunnel=smoothstep(16.,21.,cycle)*(1.-smoothstep(29.,33.,cycle)); float ang=atan(p.y,p.x); uv=mix(uv,.5+vec2(cos(ang+t*.35),sin(ang+t*.35))*pow(r,.72),tunnel*.28);
 float shock=fract(t*.145); float ring=exp(-pow((r-shock*.72)/.025,2.)); uv=.5+(uv-.5)*(1.-ring*.09);
 float lens=smoothstep(25.,29.,cycle)*(1.-smoothstep(34.,38.,cycle)); float rr=max(r,.035); uv=.5+p*(1.+lens*.035/(rr*rr));
 uv=barrel(uv,.04+.09*pulse);
 vec2 ca=(uv-.5)*(.0025+.005*pulse); vec3 scene=vec3(texture(uScene,uv+ca).r,texture(uScene,uv).g,texture(uScene,uv-ca).b);
 vec3 bloom=texture(uBloom,uv).rgb; vec3 col=scene+bloom*(.68+.55*pulse);
 // volumetric-looking portal aura and diffraction star rays
 float portal=exp(-r*7.5)*(0.35+1.4*pulse); float rays=pow(abs(cos(ang*6.+t*.3)),70.)*exp(-r*3.5); col+=vec3(1.,.018,.004)*(portal+rays*.8);
 // holographic spectral edge during metamorphosis
 float holo=smoothstep(6.,10.,cycle)*(1.-smoothstep(17.,21.,cycle)); col+=holo*.06*vec3(sin(uv.x*90.+t*4.)*.5+.5,sin(uv.x*90.+2.1+t*4.)*.5+.5,sin(uv.x*90.+4.2+t*4.)*.5+.5);
 // scanline / interlace / glitch slices, restrained except transitions
 float trans=max(smoothstep(.88,1.,fract(cycle/8.)),pulse*.35); float scan=.985+.015*sin(gl_FragCoord.y*3.14159); col*=scan;
 float slice=step(.985,hash21(vec2(floor(uv.y*90.),floor(t*12.)))); col+=slice*trans*texture(uBloom,vec2(fract(uv.x+.025*sin(t*17.)),uv.y)).rgb*.45;
 // SDF energy sculpture: nested triangular field around portal
 vec2 sp=(vUV-.5)*vec2(textureSize(uScene,0))/float(textureSize(uScene,0).y); float aa=atan(sp.y,sp.x); float tri=cos(floor(.5+aa/2.0943951)*2.0943951-aa)*length(sp); float sdf=exp(-abs(tri-.20-.025*sin(t*2.))*120.); col+=vec3(1.,.015,.002)*sdf*(.18+.5*pulse);
 // reaction-diffusion-like interference without state texture: multi-frequency domain warp
 float rd=sin((uv.x+sin(uv.y*19.+t*.3)*.03)*67.)*sin((uv.y+sin(uv.x*23.-t*.27)*.03)*61.); col+=vec3(.015,.006,.025)*rd*rd*kAmt;
 // temporal echo samples produce trails without persistent undefined feedback
 vec3 echo=texture(uScene,mix(uv,.5+(uv-.5)*1.012,.5+.5*sin(t*.2))).rgb; col=mix(col,max(col,echo*.72),tunnel*.22);
 // exposure + ACES
 col=aces(col*uExposure); col=(col-.5)*1.075+.5;
 float vig=pow(max(0.,16.*vUV.x*vUV.y*(1.-vUV.x)*(1.-vUV.y)),.16); col*=mix(.48,1.,vig);
 // chromatic sparkle / film grain
 float g=hash21(gl_FragCoord.xy+floor(t*60.))-.5; col+=g*.014;
 // collapse-to-black singularity before shockwave rebuild
 float collapse=smoothstep(31.,34.,cycle)*(1.-smoothstep(35.,37.,cycle)); col*=1.-collapse*exp(-r*5.); col+=vec3(1.,.01,0.)*ring*(.15+collapse*2.5);
 FragColor=vec4(max(col,0.),1.);
}
