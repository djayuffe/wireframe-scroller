#version 410 core
layout(location=0) in vec3 aPosition; layout(location=1) in vec3 aNormal; layout(location=2) in vec2 aUV;
uniform mat4 uModel,uView,uProjection; out vec3 vWorld,vNormal,vLocal; out vec2 vUV;
void main(){vec4 w=uModel*vec4(aPosition,1);vWorld=w.xyz;vLocal=aPosition;vUV=aUV;vNormal=normalize(transpose(inverse(mat3(uModel)))*aNormal);gl_Position=uProjection*uView*w;}
