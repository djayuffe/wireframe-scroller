# UBER — OpenGL Mega Demo ULTIMATE

Self-contained source project for a procedural demoscene-style 3D production. Runtime artwork is generated from geometry and GLSL; no generated concept image is used as a backdrop.

## Implemented systems
- OpenGL 4.1 Core renderer (macOS-compatible), C++20, GLFW/GLAD/GLM.
- Resize-safe floating-point HDR MRT framebuffer and bloom ping-pong targets.
- Procedural cube, torus, UV sphere and cylinder meshes; recursive triangular portal geometry.
- Industrial temple, wings, skyline, floating impossible slabs, orbital halos, moon, conduits, runway and emissive debris.
- Metallic/rough material shading, Fresnel, thin-film tint, procedural scratches/circuit traces, distance fog and emissive extraction.
- 48-second autonomous visual director: portal recursion, kaleidoscope, topology/hyperspace warp, gravitational lensing, singularity collapse and shockwave rebuild.
- Post effects: HDR bloom, ACES curve, chromatic aberration, barrel/lens breathing, diffraction rays, holographic spectral interference, scanlines, glitch slices, grain, vignette, procedural SDF energy sculpture, interference/reaction-style field and temporal echo sampling.
- Pause, exposure control, fullscreen toggle, resize recreation and explicit GL resource cleanup.

## Build
macOS (internet available for first dependency fetch):
```bash
./build_macos.sh
```
Manual:
```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
./build/UberMegaDemo
```
Installed dependencies can be selected with `-DUMD_USE_SYSTEM_DEPS=ON`.

## Controls
- `Esc`: quit
- `Space`: pause timeline
- `Up/Down`: exposure
- `F11`: fullscreen

## Scope / honesty
OpenGL 4.1 has no compute shaders. Effects that would conventionally use compute (large GPU particle simulation, fluid state, persistent reaction-diffusion) are implemented with deterministic procedural geometry or fragment-domain approximations so the project remains compatible with Apple's OpenGL 4.1. No feature is described as compute-driven.

## Final-pass reliability additions

The executable searches for `shaders/` from the current directory and nearby build/project directories. For unusual launch layouts set `UMD_ASSET_ROOT=/path/to/UberMegaDemo_PRODUCTION`.

F11 now restores the original window rectangle after fullscreen. Zero-sized framebuffer states (for example while minimized) are skipped safely, and Retina/backing-size changes recreate HDR/bloom targets at the correct pixel dimensions.

## Production controls added in continuation pass
- `R`: transactional shader hot reload. New programs replace the active programs only if all shaders compile/link.
- `F12`: capture the final framebuffer to a lossless binary PPM (`capture_00000.ppm`, etc.).
- `UMD_DETERMINISTIC=1`: fixed 60 Hz timeline stepping for repeatable captures and regression comparisons.
- Window title reports measured FPS, backing resolution, and demo time once per second.
- Startup prints OpenGL vendor, renderer, version, and GLSL version for support diagnostics.
