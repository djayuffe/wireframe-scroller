# UberMegaDemo final-pass audit

This pass is focused on executable reliability as well as visual output.

## Fixed
- Shader/resource lookup no longer assumes the process was launched from the project root.
- `UMD_ASSET_ROOT` can explicitly select the asset directory.
- F11 fullscreen now remembers and restores the previous window position and size.
- Minimized/zero-size framebuffers no longer trigger invalid resize/render work.
- Render targets are recreated when framebuffer pixel dimensions change (including Retina scale changes).
- HDR scene and bright-pass attachments are RGBA16F; bloom uses independent ping-pong RGBA16F targets.
- Every generated GL mesh, framebuffer, texture, renderbuffer and shader program has a destruction path.
- Delta time is capped to avoid huge animation jumps after stalls.
- Simulation time freezes cleanly when paused.
- OpenGL 4.1 Core remains the ceiling for macOS compatibility; no hidden compute-shader dependency.

## Implemented visual systems
Procedural architecture; nested portal geometry; recursive-depth portal frames; torus/orbital structures; sphere moon; cylinders/conduits; animated monoliths; impossible floating slabs; runway chase lighting; emissive debris; physically-inspired metallic/Fresnel shading; procedural scratches; thin-film tint; circuitry highlights; distance/portal fog; HDR bright extraction; separable bloom; ACES approximation; chromatic aberration; barrel/lens breathing; kaleidoscopic folding; topology/hyperspace warp; gravitational lensing; refractive shock ring; holographic spectrum; scanlines; glitch slices; SDF triangular energy sculpture; reaction/interference domain warp; temporal echo; singularity collapse/rebuild; vignette and grain.

## Validation boundary
The source tree is internally audited and archive integrity can be tested here. A real C++/OpenGL link/run requires an environment with OpenGL headers/libraries and GLFW/GLM/GLAD. The build scripts intentionally fail rather than pretending a dependency is present.
