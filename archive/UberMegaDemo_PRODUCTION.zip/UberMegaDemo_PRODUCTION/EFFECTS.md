# Effect inventory

Geometry: recursive triangular portal, industrial wings, skyline, orbital torus pair, floating rings, impossible slabs, moon sphere, energy conduits, runway grid, emissive debris.

Material: metal/roughness, Fresnel, procedural damage, circuit highlights, thin-film iridescence, emissive pulse, fog.

Screen-space: HDR bloom, ACES, chromatic aberration, barrel distortion, kaleidoscope, hyperspace topology warp, gravitational lensing, refractive shockwave, holographic spectrum, glitch slices, scanlines, diffraction rays, SDF energy triangle, interference field, temporal echo, vignette and grain.

Director: deterministic 48-second cycle with escalation, collapse and rebuild.
